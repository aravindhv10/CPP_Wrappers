// A smaple code to demonstrate the use of the mass decorrelator
//  Created by Tuhin Roy on March 29, 2019.
/*
 Take cells from an event, cluster them into jets, take the hardest jet and process it to remove all mass information from it.
 
 Example usage: ./example sample_data/ww_1.txt sample_output/ww_1_out.txt
 
 The main parameters governing the behavior of the algorithm are
 * m0: this will be the jetmass for all jets (in paper we set m0 = 0.5 GeV)
 * e0: this will be the energy for all jets (in paper we set e0 = 1.0 GeV)
 * npx and npy: if you want an image, these will be number of pixels in X and Y directions.
 */
#include "fastjet/ClusterSequence.hh"
#include "fastjet/PseudoJet.hh"
#include <iostream>
#include <sstream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <functional>
#include <cmath>
#include <numeric>
#include "MassDecorrelator.h"

using namespace std;
using namespace fastjet;

void print_jets (const fastjet::ClusterSequence &, const vector<fastjet::PseudoJet> &);
void print_jet (const fastjet::PseudoJet &);


int main (int argc, char ** argv)
{
    vector<fastjet::PseudoJet> input_particles;
    
    if(argc != 3)
    {
        cout << "Usage: example input_file output_file" << endl;
        exit(0);
    }
    
    ifstream infile(argv[1]);
    if(!infile.good())
    {
        cout << "Can't open " << argv[1] << endl;
        exit(0);
    }
    
    ofstream outfile(argv[2]);
    if(!outfile.is_open())
    {
        cout << "Can't open " << argv[2] << endl;
        exit(0);
    }


    // read in input particles from the file
    double px, py , pz, E;
    while (infile >> px >> py >> pz >> E)
        input_particles.push_back(fastjet::PseudoJet(px,py,pz,E));
    
    // choose a jet definition
    double jetR = 1.0;
    
    fastjet::JetDefinition jet_def(fastjet::antikt_algorithm,jetR,fastjet::E_scheme, fastjet::Best);
    fastjet::ClusterSequence clust_seq(input_particles, jet_def);
    vector<fastjet::PseudoJet> inclusive_jets = sorted_by_pt(clust_seq.inclusive_jets());
    
    cout <<endl <<  "============================================"<<endl;
    cout << "\tJets found in initial clustering" << endl;
    cout << "============================================"<<endl<< endl;;
    
    // print_jets(clust_seq, inclusive_jets);
    // print out some infos
    cout << "Clustering with " << jet_def.description() << endl;
    cout << "============================================"<<endl;
    
    fastjet::PseudoJet jet0 = inclusive_jets[0];
    vector<fastjet::PseudoJet> constituents0 = sorted_by_E(jet0.constituents());
    
    double m0 = 0.5;
    double e0 = 1.0;
    
    // set m0/e0 carefully. For a given jet with radius R,
    // try to set m0/e0 = (R/2). Image only cares about m0/e0.
    
    int npx = 10;
    int npy = 10;
    // useful for rectangular images -- if you feel like it.
    
    cout << "Decorrelate the jet with m0 = " <<m0 << " GeV and e0 = " << e0 << " GeV" << endl;
    cout << "============================================"<<endl;
    
    // Initialize the mass decorrelator
    MassDecorrelator decorrelated_jet(m0, e0, npx, npy);
    decorrelated_jet.UseSubjetAxes(true); // false by default
    // Decorrelation a set of vecotors (constituents of the jet)
    decorrelated_jet.Decorrelate(constituents0);
    
    /*
     Find Decorrelated constituents of the jet in the frame where jet mass is m0 and jet energy is e0.
     Each constituent 4vector is characterizeed by
     e = constituent energy in the new frame
     pvec = (px, py, px) = constituent momenta in the new frame
     The vector is sortet in energy
     */
    
    vector<fastjet::PseudoJet> fixedME_constituents = decorrelated_jet.fixedME_constituents();
    
    /*
     Express the same constituents using unit vectors (e1,e2,e3) where e1 is jet direction and the other span the transverse plane. Access the unit vector form jet_axes JA as
     JA.e1 = e1 --- etc.
     */
    jet_axes axes = decorrelated_jet.get_axes();
    
    /*
     New constituent 4vectors are characterizeed by
     e = constituent energy in the new frame
     px = pvec.e2
     py = pvec.e3
     pz = pvec.e1
     */
    
    vector<fastjet::PseudoJet> constituents_decorr = decorrelated_jet.decorrelated_constituents();
    /*
     New constituent 4vectors are converted to image_constituent I
     I.e = constituent energy in the new frame/initial jet energy
     I.x = X cordinate as integer
     I.y = Y cordinate as integer
     You can make a Root 2D Histogram if you want or make your own image from image_constituent. For accessing more info see MassDecorrelator.h
     */
    
    vector<image_constituents> image_consts2 = decorrelated_jet.get_image_constituents();

    /*
    Collect the image -- 1D vector of real numbers --
     input for your ML code or Rood Histogram.
    */
    vector<double> image1D = decorrelated_jet.get_image1D();
    
    
    for(vector<double>::iterator it = image1D.begin(); it != image1D.end(); it++)
    {
        outfile << (*it) << "\t" ;
    }
    outfile << endl;
    
    infile.close();
    outfile.close();
}

