//  MassDecorrelator.h
//  Created by Tuhin Roy on March 29, 2019.
#ifndef _MASSDECORRELATOR_
#define _MASSDECORRELATOR_
#include <iostream>
#include <sstream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <functional>
#include <cmath>
#include <numeric>
#include "fastjet/JetDefinition.hh"
#include "fastjet/PseudoJet.hh"
using namespace std;

struct jet_axes{
    fastjet::PseudoJet e1;
    fastjet::PseudoJet e2;
    fastjet::PseudoJet e3;
};

class image_constituents{
private:
    double _e;
    int _x, _y;
public:
    image_constituents(double e, int x, int y) : _e(e), _x(x), _y(y) { };
    image_constituents() : _e(0.0), _x(0), _y(0) { };
    double e() {return _e;};
    int x() {return _x;};
    int y() {return _y;};
};


class MassDecorrelator{
private:
    bool _subjet_axes_used;
    //unsigned int _which_subjets;
    double _m0, _e0;
    int _npx, _npy;
    vector<fastjet::PseudoJet> _Ori_jets;
    vector<fastjet::PseudoJet> _M_Fixed_jets;
    vector<fastjet::PseudoJet> _ME_Fixed_jets;
    vector<fastjet::PseudoJet> _MERotn_Fixed_jets;
    jet_axes _axes;
    vector<image_constituents> _image_consts;
    vector<double> _image1D;
    void FixM(vector<fastjet::PseudoJet> jets, double rfactor);
    void FixE(vector<fastjet::PseudoJet> jets, const fastjet::PseudoJet & ehat, double e0);
    void SetAxes(vector<fastjet::PseudoJet> & jets);
    void RotateJets(vector<fastjet::PseudoJet> & jets, jet_axes axes);
    void MakeImage(vector<fastjet::PseudoJet> & jets, int npx, int npy);
    fastjet::PseudoJet LorentzTransform(fastjet::PseudoJet & jet, const fastjet::PseudoJet & ehat, double gamma);
    jet_axes FindAxes(vector<fastjet::PseudoJet> jets, bool _subjet_axes_used);
    fastjet::PseudoJet Get_dirn (const fastjet::PseudoJet & jetJ);
    
public:
    MassDecorrelator(double m0, double e0, int npx, int npy);
    void Decorrelate(vector<fastjet::PseudoJet> & jets);
    jet_axes get_axes() {return _axes;};
    vector<fastjet::PseudoJet> decorrelated_constituents() {return _MERotn_Fixed_jets;};
    vector<fastjet::PseudoJet> fixedM_constituents() {return _M_Fixed_jets;};
    vector<fastjet::PseudoJet> fixedME_constituents() {return _ME_Fixed_jets;};
    vector<fastjet::PseudoJet> original_constituents() {return _Ori_jets;};
    vector<image_constituents> get_image_constituents(){return _image_consts;};
    vector<double> get_image1D(){return _image1D;};
    void UseSubjetAxes(bool use_subjets);
};





#endif /* defined(____QEvents__) */
