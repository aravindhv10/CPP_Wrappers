//  MassDecorrelator.C
//  Created by Tuhin Roy on March 29, 2019.

#include "MassDecorrelator.h"



MassDecorrelator::MassDecorrelator( double m0, double e0, int npx, int npy)
:  _m0(m0), _e0(e0), _npx(npx), _npy(npy), _subjet_axes_used(false)
{
}

void MassDecorrelator::Decorrelate(vector<fastjet::PseudoJet> & jets)
{
    _Ori_jets = jets;
    fastjet::PseudoJet jetJ = accumulate(_Ori_jets.begin(), _Ori_jets.end(),fastjet::PseudoJet(0,0,0,0));
    
    double rfactor = _m0/jetJ.m();
    FixM(_Ori_jets, rfactor);
    
    const fastjet::PseudoJet ehat = Get_dirn (jetJ);
    double gamma;
    double modp = rfactor*sqrt(jetJ.modp2());
    double p0 = sqrt (_e0 * _e0 - _m0 * _m0 );
    
    if (_e0 < rfactor*jetJ.e())
        gamma = (rfactor*jetJ.e()*_e0 - p0* modp )/(_m0 * _m0);
    else
        gamma = (rfactor*jetJ.e()*_e0 + p0* modp )/(_m0 * _m0);
    
    
    
    FixE(_M_Fixed_jets, ehat, gamma);
    _ME_Fixed_jets = sorted_by_E(_ME_Fixed_jets);

    
    SetAxes(_ME_Fixed_jets);
    RotateJets(_ME_Fixed_jets, _axes);
    
    MakeImage(_MERotn_Fixed_jets, _npx, _npy);

}

void MassDecorrelator::UseSubjetAxes(bool use_subjets)
{
    _subjet_axes_used = use_subjets;
    //_which_subjets = which_subjets;
}

void MassDecorrelator::SetAxes(vector<fastjet::PseudoJet> & consts)
{
    fastjet::PseudoJet  jet0 = accumulate(consts.begin(), consts.end(), fastjet::PseudoJet(0,0,0,0) );
    
    const int njets = 3;
    double R = 10.0;
    fastjet::JetDefinition jet_def(fastjet::kt_algorithm, R);
    fastjet::ClusterSequence cs(consts, jet_def);
    vector<fastjet::PseudoJet> nsubjets = sorted_by_E(cs.exclusive_jets_up_to (njets));
    
    
    vector<fastjet::PseudoJet> jets;
    if(_subjet_axes_used)
        jets = nsubjets;
    else
        jets = consts;
    
    
    assert( jets.size() > 2) ;
 
    fastjet::PseudoJet jet1 = jets[0];
    fastjet::PseudoJet jet2 = jets[1];
    
    
    _axes.e1 = Get_dirn (jet0);
    _axes.e2 = Get_dirn(jet1 + dot_product(jet1, _axes.e1)* _axes.e1);
    _axes.e3 = Get_dirn(jet2 + dot_product(jet2, _axes.e1)* _axes.e1+dot_product(jet2, _axes.e2)* _axes.e2);
    
}

void MassDecorrelator::RotateJets(vector<fastjet::PseudoJet> & jets, jet_axes axes)
{
    _MERotn_Fixed_jets.resize(jets.size());
    transform (jets.begin(), jets.end(),_MERotn_Fixed_jets.begin(),
               [&](fastjet::PseudoJet & a)
               { return fastjet::PseudoJet
                   (-dot_product(axes.e2,a),
                     -dot_product(axes.e3,a),
                       -dot_product(axes.e1,a),  a.e() );
               } );
}

void MassDecorrelator::FixM(vector<fastjet::PseudoJet> consts, double rfactor)
{
    _M_Fixed_jets.resize(consts.size());
    std::transform (consts.begin(), consts.end(),_M_Fixed_jets.begin(), [ & ](fastjet::PseudoJet & a){ return rfactor*a; } );
}

void MassDecorrelator::FixE(vector<fastjet::PseudoJet> consts, const fastjet::PseudoJet & ehat, double gamma)
{
    _ME_Fixed_jets.resize(consts.size());
    std::transform (consts.begin(), consts.end(),_ME_Fixed_jets.begin(), [ & ](fastjet::PseudoJet & a){ return   LorentzTransform (a, ehat, gamma); } );
}

void MassDecorrelator::MakeImage(vector<fastjet::PseudoJet> & consts,  int npx, int npy)
{
    int npxp1 = (npx+1);
    int npxm1 = (npx-1);
    int npyp1 = (npy+1);
    int npym1 = (npy-1);
    
    
    fastjet::PseudoJet JetJ = accumulate(consts.begin(), consts.end(), fastjet::PseudoJet(0,0,0,0));
    
    
    vector<image_constituents> image_consts(1, image_constituents());
    image_consts.resize(consts.size());
    
    transform (consts.begin(), consts.end(), image_consts.begin(),
               [&](fastjet::PseudoJet & a)
               { return image_constituents (a.e()/JetJ.e(),
                        floor((a.px()*npxm1)/(2* a.e()) + npxp1/(2.0) ),
                        floor((a.py()*npym1)/(2* a.e())+npyp1/(2.0))  ); } );
    
    _image_consts = image_consts;
    _image1D.resize(npx*npy, 0);
    for(vector<image_constituents>::iterator it = image_consts.begin(); it != image_consts.end(); it++)
    {
        int x1D = (*it).x() + npx*((*it).y()-1) ;
        _image1D[x1D-1] += (*it).e();
    }
    
 
}


fastjet::PseudoJet  MassDecorrelator::LorentzTransform (fastjet::PseudoJet & jetJ, const fastjet::PseudoJet & ehat, double gamma)
{
    double beta = sqrt (1.0 - 1.0/(gamma*gamma) );
    fastjet::PseudoJet pn = jetJ -  ( gamma - 1.0 )*dot_product(ehat,jetJ)*ehat - gamma*beta*jetJ.e()*ehat;
    double en = gamma*( jetJ.e() +  beta*dot_product(ehat,jetJ));
    
    return fastjet::PseudoJet ( pn.px(),pn.py(), pn.pz(), en);

}


fastjet::PseudoJet  MassDecorrelator::Get_dirn (const fastjet::PseudoJet & jetJ)
{
    fastjet::PseudoJet ret;
    ret = fastjet::PseudoJet (jetJ.px(), jetJ.py(), jetJ.pz(), 0.0);
    ret = ret/fabs(sqrt(jetJ.modp2()));
    
    return ret;
}
